#!/usr/bin/env python
# -*- coding: utf-8 -*-

# ===================================================================
# PINN Conductivity Prediction Script
# Function: Loads the trained Physics-Informed Neural Network (PINN) 
# and Graph Neural Network (GNN) to predict ionic conductivity for 
# candidate crystals in the specified directory.
# ===================================================================

import os
import re
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import pymatgen.core as mg
from sklearn.preprocessing import StandardScaler
import traceback
import pickle

# ===================================================================
# PART 1: Constants and Path Configuration
# ===================================================================

# --- Directory containing target POSCAR files for prediction ---
PREDICTION_DIRECTORY = "./predict_data"

# --- Paths to the saved model and auxiliary files (Must match training output) ---
SAVED_MODEL_PATH = "pinn_conductivity_model.pth" 
SAVED_SCALER_PATH = "feature_scaler.pkl"
SAVED_SPG_MAP_PATH = "spacegroup_map.pkl"

# ===================================================================
# PART 2: Data Processing Functions
# ===================================================================

def parse_poscar_with_explicit_features(filepath):
    if not os.path.exists(filepath): 
        raise FileNotFoundError(f"File not found: '{filepath}'")
    with open(filepath, 'r', encoding='utf-8') as f: 
        lines = f.readlines()
        
    comment_line = lines[0].strip()
    spg_symbol = "P1"
    spg_match = re.search(r'\(([^)]+)\)', comment_line)
    if spg_match:
        spg_symbol = spg_match.group(1).strip().replace(" ", "")
    else:
        parts_comment = comment_line.split()
        if parts_comment: spg_symbol = parts_comment[0]
        
    scale = float(lines[1].strip())
    lattice = np.array([list(map(float, line.split())) for line in lines[2:5]]) * scale
    
    coord_start_line = 8
    if len(lines) > 7 and lines[7].strip().lower().startswith('s'): 
        coord_start_line = 9
        
    species_list, coords, static_features_list = [], [], []
    for line in lines[coord_start_line:]:
        parts = line.strip().split()
        if not parts: continue
        try:
            coords.append([float(p) for p in parts[:3]])
            ion_name_idx, current_species = -1, ""
            for j, part in enumerate(parts):
                match = re.search(r'[A-Za-z]+', part)
                if match: 
                    current_species = match.group(0)
                    ion_name_idx = j
                    break
            if not current_species: raise ValueError("Element symbol missing.")
            species_list.append(current_species)
            
            features = [float(p) for p in parts[ion_name_idx+1:] if p.replace('.', '', 1).replace('-', '', 1).isdigit()] if ion_name_idx != -1 and ion_name_idx + 1 < len(parts) else []
            static_features_list.append(features if len(features) == 30 else [0.0]*30)
        except (ValueError, IndexError): continue
        
    if not species_list: raise ValueError(f"Parsing error: No valid atoms found.")
    structure = mg.Structure(lattice, species_list, coords, coords_are_cartesian=False)
    return structure, np.array(static_features_list), spg_symbol

def prepare_graph_data(structure, neighbor_radius=6.0):
    atomic_numbers = [site.specie.Z for site in structure]
    edge_index, distances = [], []
    for i in range(len(structure)):
        neighbors = structure.get_neighbors(structure[i], r=neighbor_radius)
        for site, distance, j, _ in neighbors:
            edge_index.append([i, j])
            distances.append(distance)
    edge_index = np.array(edge_index).T if edge_index else np.empty((2, 0))
    return (torch.tensor(atomic_numbers, dtype=torch.long), 
            torch.tensor(edge_index, dtype=torch.long), 
            torch.tensor(np.array(distances), dtype=torch.float))

# ===================================================================
# PART 3: Deep Learning Architecture (Matches Training Script)
# ===================================================================

class AtomEmbedding(nn.Module):
    def __init__(self, embed_dim):
        super().__init__()
        self.embedding = nn.Embedding(101, embed_dim)
    def forward(self, atomic_numbers): return self.embedding(atomic_numbers)

class CGCNNConvLayer(nn.Module):
    def __init__(self, atom_feat_dim, edge_feat_dim):
        super().__init__()
        total_feat_dim = 2 * atom_feat_dim + edge_feat_dim
        self.filter_net = nn.Sequential(nn.Linear(total_feat_dim, atom_feat_dim), nn.Softplus())
        self.gate_net = nn.Sequential(nn.Linear(total_feat_dim, atom_feat_dim), nn.Sigmoid())
    def forward(self, x, edge_index, edge_attr):
        row, col = edge_index; x_i, x_j = x[row], x[col]
        total_features = torch.cat([x_i, x_j, edge_attr], dim=1)
        message = self.filter_net(total_features) * self.gate_net(total_features)
        aggregated_message = torch.zeros(x.size(0), x.size(1), device=x.device, dtype=x.dtype)
        aggregated_message.scatter_add_(0, row.unsqueeze(1).expand_as(message), message)
        return x + aggregated_message

class GaussianExpansion(nn.Module):
    def __init__(self, dmin=0.0, dmax=8.0, steps=40):
        super().__init__()
        self.delta = (dmax - dmin) / steps
        self.centers = torch.arange(dmin, dmax, self.delta)
    def forward(self, distances):
        distances = distances.unsqueeze(-1)
        return torch.exp(-((distances - self.centers.to(distances.device))**2) / (self.delta**2))

class SpaceGroupEmbedding(nn.Module):
    def __init__(self, vocab_size, embed_dim):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
    def forward(self, spg_indices): return self.embedding(spg_indices.squeeze(-1)).unsqueeze(0)

class FullyConnectedLayers(nn.Module):
    def __init__(self, input_dim, layer_dims, output_dim, dropout_rate=0.5):
        super().__init__(); layers = []
        for hidden_dim in layer_dims:
            layers.extend([nn.Linear(int(input_dim), hidden_dim), nn.ReLU()])
            if dropout_rate > 0: layers.append(nn.Dropout(p=dropout_rate))
            input_dim = hidden_dim
        self.fc_layers = nn.Sequential(*layers)
        self.output_layer = nn.Linear(input_dim, output_dim)
    def forward(self, x): return self.output_layer(self.fc_layers(x))

class MultiHeadAttentionPooling(nn.Module):
    def __init__(self, in_dim, n_heads=4):
        super().__init__(); self.n_heads = n_heads
        self.attn_scorer = nn.Linear(in_dim, n_heads)
        self.value_transform = nn.Linear(in_dim, in_dim * n_heads)
    def forward(self, x):
        attn_weights = F.softmax(self.attn_scorer(x), dim=0)
        values = self.value_transform(x).view(-1, self.n_heads, x.size(1))
        return torch.sum(attn_weights.unsqueeze(-1) * values, dim=0).view(1, -1)

class CrystalModel(nn.Module):
    def __init__(self, static_feat_dim, atom_embed_dim, edge_feat_dim,
                 spacegroup_vocab_size, spg_embed_dim, fc_hidden_dims, output_dim, 
                 pooling_heads=4, dropout_rate=0.5):
        super().__init__()
        self.atom_embedding = AtomEmbedding(atom_embed_dim)
        self.feature_mlp = nn.Sequential(nn.Linear(static_feat_dim, atom_embed_dim), nn.ReLU())
        self.gaussian_expansion = GaussianExpansion(steps=edge_feat_dim)
        self.cgcnn_conv = CGCNNConvLayer(atom_embed_dim, edge_feat_dim)
        self.spacegroup_embedding = SpaceGroupEmbedding(spacegroup_vocab_size, spg_embed_dim)
        self.attention_pooling = MultiHeadAttentionPooling(atom_embed_dim, n_heads=pooling_heads)
        self.fc_layers = FullyConnectedLayers(atom_embed_dim * pooling_heads + spg_embed_dim, fc_hidden_dims, output_dim, dropout_rate=dropout_rate)

    def forward(self, batch):
        x = self.atom_embedding(batch['atomic_numbers']) + self.feature_mlp(batch['static_features'])
        x = self.cgcnn_conv(x, batch['edge_index'], self.gaussian_expansion(batch['distances']))
        combined_features = torch.cat((self.attention_pooling(x), self.spacegroup_embedding(batch['spacegroup_idx'])), dim=1)
        return self.fc_layers(combined_features)

# ===================================================================
# PART 4: Main Prediction Pipeline
# ===================================================================

def run_prediction():
    print("======== Initializing PINN Batch Prediction ========")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[INFO] Computing Device: {device}")
    
    try:
        with open(SAVED_SCALER_PATH, 'rb') as f: feature_scaler = pickle.load(f)
        with open(SAVED_SPG_MAP_PATH, 'rb') as f: spg_map = pickle.load(f)
        
        model = CrystalModel(
            static_feat_dim=30, atom_embed_dim=64, edge_feat_dim=40,
            spacegroup_vocab_size=len(spg_map), spg_embed_dim=16, 
            fc_hidden_dims=[256, 128], output_dim=1, pooling_heads=4, dropout_rate=0.3
        )
        model.load_state_dict(torch.load(SAVED_MODEL_PATH, map_location=device, weights_only=True))
        model.to(device)
        model.eval()
        print("[INFO] Pre-trained Model, Scaler, and Spacegroup Map loaded successfully.")
    except Exception as e:
        print(f"[FATAL ERROR] Required model files missing or corrupted: {e}")
        return

    if not os.path.isdir(PREDICTION_DIRECTORY):
        print(f"[ERROR] Prediction directory '{PREDICTION_DIRECTORY}' does not exist.")
        return
        
    structure_files = [f for f in os.listdir(PREDICTION_DIRECTORY) if f.lower().endswith(".poscar")]
    if not structure_files:
        print(f"[WARNING] No .poscar files found in '{PREDICTION_DIRECTORY}'.")
        return
        
    print(f"\n[INFO] Found {len(structure_files)} crystal structures. Starting prediction...")
    print("-" * 65)
    print(f"{'Filename':<40} | {'Predicted Conductivity (log mS/cm)'}")
    print("-" * 65)

    with torch.no_grad():
        for filename in structure_files:
            filepath = os.path.join(PREDICTION_DIRECTORY, filename)
            try:
                structure, static_features_np, spg_symbol = parse_poscar_with_explicit_features(filepath)
                spg_idx = spg_map.get(spg_symbol, spg_map.get("UNKNOWN_SPG", 0))
                
                if static_features_np.size > 0:
                    scaled_features = feature_scaler.transform(static_features_np)
                    static_features = torch.tensor(np.nan_to_num(scaled_features), dtype=torch.float)
                else:
                    static_features = torch.tensor(static_features_np, dtype=torch.float)

                atomic_numbers, edges, distances = prepare_graph_data(structure)

                batch = {
                    'atomic_numbers': atomic_numbers.to(device),
                    'static_features': static_features.to(device),
                    'edge_index': edges.to(device),
                    'distances': distances.to(device),
                    'spacegroup_idx': torch.tensor(spg_idx, dtype=torch.long).to(device)
                }

                prediction_value = model(batch).item()
                print(f"{filename:<40} | {prediction_value:>15.4f}")

            except Exception as e:
                print(f"{filename:<40} | [FAILED] {e}")

    print("-" * 65)
    print("======== Batch Prediction Completed ========\n")

if __name__ == '__main__':
    run_prediction()