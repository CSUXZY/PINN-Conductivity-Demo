# ===================================================================
# PART 1: Imports and Constants
# ===================================================================
import os
import re
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import pymatgen.core as mg
from sklearn.preprocessing import StandardScaler
import traceback
import pickle
from sklearn.model_selection import train_test_split
from torch.optim.lr_scheduler import ReduceLROnPlateau

# --- Path and Constants Configuration ---
# Note for reviewers: Place the sample POSCAR files and the target.xlsx in this directory.
TRAINING_DIRECTORY = "./train_data"
TARGET_EXCEL_FILE = "target.xlsx"

# Saved model and scaler paths
SAVED_MODEL_PATH = "pinn_conductivity_model.pth" 
SAVED_SCALER_PATH = "feature_scaler.pkl"
SAVED_SPG_MAP_PATH = "spacegroup_map.pkl"

# ===================================================================
# PART 2: Data Processing and Graph Construction
# ===================================================================

def parse_poscar_with_explicit_features(filepath):
    """Parses VASP POSCAR files to extract crystal structures and local ionic features."""
    if not os.path.exists(filepath): 
        raise FileNotFoundError(f"File not found: '{filepath}'")
    
    with open(filepath, 'r', encoding='utf-8') as f: 
        lines = f.readlines()
        
    comment_line = lines[0].strip()
    spg_symbol = "P1"
    spg_match = re.search(r'\(([^)]+)\)', comment_line)
    if spg_match:
        spg_symbol = spg_match.group(1).strip().replace(" ", "")
    else:
        parts_comment = comment_line.split()
        if parts_comment: 
            spg_symbol = parts_comment[0]
            
    scale = float(lines[1].strip())
    lattice = np.array([list(map(float, line.split())) for line in lines[2:5]]) * scale
    
    coord_start_line = 8
    if len(lines) > 7 and lines[7].strip().lower().startswith('s'): 
        coord_start_line = 9
        
    species_list, coords, static_features_list = [], [], []
    for line in lines[coord_start_line:]:
        parts = line.strip().split()
        if not parts: continue
        try:
            coords.append([float(p) for p in parts[:3]])
            ion_name_idx, current_species = -1, ""
            for j, part in enumerate(parts):
                match = re.search(r'[A-Za-z]+', part)
                if match: 
                    current_species = match.group(0)
                    ion_name_idx = j
                    break
            if not current_species: 
                raise ValueError("Element symbol not found in coordinate line.")
            species_list.append(current_species)
            
            features = [float(p) for p in parts[ion_name_idx+1:] if p.replace('.', '', 1).replace('-', '', 1).isdigit()] if ion_name_idx != -1 and ion_name_idx + 1 < len(parts) else []
            # Extract exactly 30 explicit ionic features
            static_features_list.append(features if len(features) == 30 else [0.0]*30)
        except (ValueError, IndexError): 
            continue
            
    if not species_list: 
        raise ValueError(f"Parsing error: No atoms extracted from '{os.path.basename(filepath)}'.")
        
    structure = mg.Structure(lattice, species_list, coords, coords_are_cartesian=False)
    return structure, np.array(static_features_list), spg_symbol

def prepare_graph_data(structure, neighbor_radius=6.0):
    """Constructs adjacency matrix and distance vectors for the Graph Neural Network."""
    atomic_numbers = [site.specie.Z for site in structure]
    edge_index, distances = [], []
    for i in range(len(structure)):
        neighbors = structure.get_neighbors(structure[i], r=neighbor_radius)
        for site, distance, j, _ in neighbors:
            edge_index.append([i, j])
            distances.append(distance)
    edge_index = np.array(edge_index).T if edge_index else np.empty((2, 0))
    return (torch.tensor(atomic_numbers, dtype=torch.long), 
            torch.tensor(edge_index, dtype=torch.long), 
            torch.tensor(np.array(distances), dtype=torch.float))

# ===================================================================
# PART 3: Physics-Informed Perturbations (PINN Rules)
# ===================================================================

def perturb_features(static_features):
    """
    Introduces physics-guided perturbations to the input features to enforce 
    fundamental physical constraints in the loss function.
    """
    perturbed = static_features.clone()
    num_atoms = perturbed.size(0)

    # Constraint 1: Coulombic Interactions (Fluctuations in local electronegativity < 0.2)
    # Indices: Self EN (4), Neighbor ENs (11-16), Mean diff (17), Max diff (19)
    en_indices_to_perturb = [4] + list(range(11, 17)) + [17, 19]
    for i in en_indices_to_perturb:
        delta_en = (torch.rand(num_atoms, device=static_features.device) - 0.5) * 0.398
        perturbed[:, i] += delta_en

    # Constraint 2: Lattice Stability (Variations in bond lengths < 5%)
    # Indices: Neighbor distances (20-25), Bond length deviations (26-29)
    bond_indices_to_perturb = list(range(20, 30))
    for i in bond_indices_to_perturb:
        original_values = perturbed[:, i]
        percentage_change = (torch.rand(num_atoms, device=static_features.device) - 0.5) * 0.098
        delta_bond = original_values * percentage_change
        perturbed[:, i] += delta_bond

    # Constraint 3: Dispersive Forces (Conservation of IE + EA sum)
    # Indices: First Ionization Energy (5), Electron Affinity (6)
    delta_ie = (torch.rand(num_atoms, 1, device=static_features.device) - 0.5) * 0.1
    perturbed[:, 5] += delta_ie.squeeze()
    perturbed[:, 6] -= delta_ie.squeeze()

    # Constraint 4: Skeleton Rigidity (Invariant non-mobile cation oxidation/radius ratio)
    ox_state_index = 2
    radius_index = 3
    atomic_num_index = 1
    
    # Identify non-lithium cations (Oxidation state > 0, Atomic number != 3)
    cation_mask = (static_features[:, ox_state_index] > 0) & (static_features[:, atomic_num_index] != 3)
    cation_indices = torch.where(cation_mask)[0]
    
    if cation_indices.numel() > 0:
        original_ox = static_features[cation_indices, ox_state_index]
        original_radius = static_features[cation_indices, radius_index]
        
        # Prevent division by zero
        original_radius[original_radius.abs() < 1e-6] = 1e-6
        original_ratio = original_ox / original_radius
        
        # Introduce a minor oxidation state variance
        delta_ox = (torch.rand_like(original_ox) - 0.5) * 0.1
        new_ox = original_ox + delta_ox
        
        # Adjust radius to maintain the structural rigidity ratio
        new_radius = new_ox / original_ratio
        
        perturbed[cation_indices, ox_state_index] = new_ox
        perturbed[cation_indices, radius_index] = new_radius

    return perturbed

# ===================================================================
# PART 4: Deep Learning Architecture
# ===================================================================

class AtomEmbedding(nn.Module):
    def __init__(self, embed_dim):
        super().__init__()
        self.embedding = nn.Embedding(101, embed_dim)
    def forward(self, atomic_numbers):
        return self.embedding(atomic_numbers)

class CGCNNConvLayer(nn.Module):
    def __init__(self, atom_feat_dim, edge_feat_dim):
        super().__init__()
        total_feat_dim = 2 * atom_feat_dim + edge_feat_dim
        self.filter_net = nn.Sequential(nn.Linear(total_feat_dim, atom_feat_dim), nn.Softplus())
        self.gate_net = nn.Sequential(nn.Linear(total_feat_dim, atom_feat_dim), nn.Sigmoid())
    def forward(self, x, edge_index, edge_attr):
        row, col = edge_index; x_i, x_j = x[row], x[col]
        total_features = torch.cat([x_i, x_j, edge_attr], dim=1)
        filtered_features = self.filter_net(total_features)
        gated_features = self.gate_net(total_features)
        message = filtered_features * gated_features
        num_atoms = x.size(0)
        aggregated_message = torch.zeros(num_atoms, x.size(1), device=x.device, dtype=x.dtype)
        aggregated_message.scatter_add_(0, row.unsqueeze(1).expand_as(message), message)
        return x + aggregated_message

class GaussianExpansion(nn.Module):
    def __init__(self, dmin=0.0, dmax=8.0, steps=40):
        super().__init__()
        self.delta = (dmax - dmin) / steps
        self.centers = torch.arange(dmin, dmax, self.delta)
    def forward(self, distances):
        distances = distances.unsqueeze(-1)
        centers = self.centers.to(distances.device)
        return torch.exp(-((distances - centers)**2) / (self.delta**2))

class SpaceGroupEmbedding(nn.Module):
    def __init__(self, vocab_size, embed_dim):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
    def forward(self, spg_indices):
        return self.embedding(spg_indices.squeeze(-1)).unsqueeze(0)

class FullyConnectedLayers(nn.Module):
    def __init__(self, input_dim, layer_dims, output_dim, dropout_rate=0.5):
        super().__init__(); layers = []; input_dim = int(input_dim)
        for hidden_dim in layer_dims:
            layers.append(nn.Linear(input_dim, hidden_dim)); layers.append(nn.ReLU())
            if dropout_rate > 0: layers.append(nn.Dropout(p=dropout_rate))
            input_dim = hidden_dim
        self.fc_layers = nn.Sequential(*layers)
        self.output_layer = nn.Linear(input_dim, output_dim)
    def forward(self, x): 
        return self.output_layer(self.fc_layers(x))

class MultiHeadAttentionPooling(nn.Module):
    def __init__(self, in_dim, n_heads=4):
        super().__init__(); self.n_heads = n_heads
        self.attn_scorer = nn.Linear(in_dim, n_heads)
        self.value_transform = nn.Linear(in_dim, in_dim * n_heads)
    def forward(self, x):
        attn_logits = self.attn_scorer(x)
        attn_weights = F.softmax(attn_logits, dim=0)
        values = self.value_transform(x).view(-1, self.n_heads, x.size(1))
        weighted_sum = torch.sum(attn_weights.unsqueeze(-1) * values, dim=0)
        return weighted_sum.view(1, -1)

class CrystalModel(nn.Module):
    def __init__(self, static_feat_dim, atom_embed_dim, edge_feat_dim,
                 spacegroup_vocab_size, spg_embed_dim, fc_hidden_dims, output_dim, 
                 pooling_heads=4, dropout_rate=0.5):
        super().__init__()
        self.dropout_rate = dropout_rate
        self.atom_embedding = AtomEmbedding(atom_embed_dim)
        self.feature_mlp = nn.Sequential(nn.Linear(static_feat_dim, atom_embed_dim), nn.ReLU())
        self.gaussian_expansion = GaussianExpansion(steps=edge_feat_dim)
        self.cgcnn_conv = CGCNNConvLayer(atom_embed_dim, edge_feat_dim)
        self.spacegroup_embedding = SpaceGroupEmbedding(spacegroup_vocab_size, spg_embed_dim)
        self.attention_pooling = MultiHeadAttentionPooling(atom_embed_dim, n_heads=pooling_heads)
        combined_fc_input_dim = (atom_embed_dim * pooling_heads) + spg_embed_dim
        self.fc_layers = FullyConnectedLayers(combined_fc_input_dim, fc_hidden_dims, output_dim, dropout_rate=dropout_rate)
        
    def forward(self, batch):
        atomic_numbers, static_features = batch['atomic_numbers'], batch['static_features']
        edge_index, distances = batch['edge_index'], batch['distances']
        
        learnable_feats = self.atom_embedding(atomic_numbers)
        static_feats_proj = self.feature_mlp(static_features)
        x = learnable_feats + static_feats_proj
        
        edge_attr = self.gaussian_expansion(distances)
        x = self.cgcnn_conv(x, edge_index, edge_attr)
        graph_feat = self.attention_pooling(x)
        
        spg_embedding = self.spacegroup_embedding(batch['spacegroup_idx'])
        combined_features = torch.cat((graph_feat, spg_embedding), dim=1)
        
        return self.fc_layers(combined_features)

class CrystalDataset(Dataset):
    def __init__(self, directory, file_list, spg_map, target_data, feature_scaler=None):
        self.directory = directory
        self.file_list = file_list
        self.spg_map = spg_map
        self.target_data = target_data
        self.feature_scaler = feature_scaler
        self.data_samples = self._preprocess_data()
        
    def _preprocess_data(self):
        samples = []
        for file in self.file_list:
            filepath = os.path.join(self.directory, file)
            structure_name = os.path.splitext(file)[0]
            if structure_name not in self.target_data: continue
            try:
                structure, static_features_np, spg_symbol = parse_poscar_with_explicit_features(filepath)
                spg_idx = self.spg_map.get(spg_symbol, self.spg_map.get("UNKNOWN_SPG", 0))
                
                if self.feature_scaler and static_features_np.size > 0:
                    scaled_features = self.feature_scaler.transform(static_features_np)
                    static_features = torch.tensor(np.nan_to_num(scaled_features), dtype=torch.float)
                else: 
                    static_features = torch.tensor(static_features_np, dtype=torch.float)
                    
                atomic_numbers, edges, distances = prepare_graph_data(structure)
                
                samples.append({
                    'structure_name': structure_name, 
                    'atomic_numbers': atomic_numbers, 
                    'static_features': static_features, 
                    'edge_index': edges, 
                    'distances': distances, 
                    'spacegroup_idx': torch.tensor(spg_idx, dtype=torch.long), 
                    'global_label': torch.tensor([self.target_data.get(structure_name, 0.0)], dtype=torch.float)
                })
            except Exception as e:
                print(f"[Warning] Failed to process {file}. Skipped. Reason: {e}")
        return samples
        
    def __len__(self): return len(self.data_samples)
    def __getitem__(self, idx): return self.data_samples[idx]

def custom_collate_fn(batch):
    if len(batch) == 1: return batch[0]
    raise NotImplementedError("Batch size > 1 is not supported in this simplified demo.")

# ===================================================================
# PART 5: Main Training Pipeline
# ===================================================================

if __name__ == '__main__':
    print("======== Initializing PINN Training Framework ========")
    try:
        df_target = pd.read_excel(os.path.join(TRAINING_DIRECTORY, TARGET_EXCEL_FILE))
        target_map = {str(r['id']).strip(): float(r['target']) for _, r in df_target.iterrows() if pd.notna(r['id']) and pd.notna(r['target'])}
        
        structure_files = [f for f in os.listdir(TRAINING_DIRECTORY) if f.lower().endswith(".poscar")]
        print(f"[INFO] Discovered {len(structure_files)} .poscar files for training/validation.")
        
        print("[INFO] Constructing Space Group Vocabulary...")
        unique_spg = set()
        for f in structure_files:
            try:
                _, _, spg = parse_poscar_with_explicit_features(os.path.join(TRAINING_DIRECTORY, f))
                unique_spg.add(spg)
            except Exception: continue
        unique_spg.add("UNKNOWN_SPG")
        SPACEGROUP_MAP = {symbol: idx for idx, symbol in enumerate(sorted(list(unique_spg)))}
        print(f"[INFO] Space Group Vocabulary built: {len(SPACEGROUP_MAP)} unique groups.")

        train_files, val_files = train_test_split(structure_files, test_size=0.1, random_state=42)
        
        print("[INFO] Fitting StandardScaler for static features...")
        feature_scaler_instance = None
        train_features_list = []
        for f in train_files:
            try:
                if os.path.getsize(os.path.join(TRAINING_DIRECTORY, f)) > 0:
                    _, features, _ = parse_poscar_with_explicit_features(os.path.join(TRAINING_DIRECTORY, f))
                    train_features_list.append(features)
            except Exception: continue
            
        if train_features_list:
            all_train_features_np = np.concatenate([f for f in train_features_list if f.ndim == 2 and f.shape[1] == 30], axis=0)
            if all_train_features_np.shape[0] > 0:
                feature_scaler_instance = StandardScaler().fit(all_train_features_np)
                print("[INFO] StandardScaler fitting completed.")
        
        print("[INFO] Generating Datasets...")
        train_dataset = CrystalDataset(TRAINING_DIRECTORY, train_files, SPACEGROUP_MAP, target_map, feature_scaler_instance)
        val_dataset = CrystalDataset(TRAINING_DIRECTORY, val_files, SPACEGROUP_MAP, target_map, feature_scaler_instance)
        train_loader = DataLoader(train_dataset, batch_size=1, shuffle=True, collate_fn=custom_collate_fn, num_workers=0)
        val_loader = DataLoader(val_dataset, batch_size=1, shuffle=False, collate_fn=custom_collate_fn, num_workers=0)
        
        print(f"[INFO] Datasets ready: Training set ({len(train_dataset)}), Validation set ({len(val_dataset)}).")
        if not train_dataset: raise RuntimeError("Training set is empty. Please check sample data.")
        
        # Initialize Model Architecture
        model = CrystalModel(
            static_feat_dim=30, atom_embed_dim=64, edge_feat_dim=40,
            spacegroup_vocab_size=len(SPACEGROUP_MAP), spg_embed_dim=16, 
            fc_hidden_dims=[256, 128], output_dim=1, 
            pooling_heads=4, dropout_rate=0.3
        )
        
        optimizer = optim.Adam(model.parameters(), lr=2e-4, weight_decay=1e-5)
        scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=15, verbose=True)
        criterion = nn.L1Loss()
        
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        print(f"\n======== Executing Training on Device: {device} ========")
        
        # Physics-informed loss weights
        RULE_WEIGHT = 1.0    # \lambda_r for perturbation consistency
        NO_LI_WEIGHT = 0.1   # \lambda_noLi for zero-conductivity prior
        
        best_val_loss = float('inf')
        patience_counter = 0
        PATIENCE_LIMIT = 30
        
        for epoch in range(200):
            model.train()
            train_ld_list, train_lr_list, train_lnl_list = [], [], []
            
            for batch in train_loader:
                for k, v in batch.items():
                    if isinstance(v, torch.Tensor): 
                        batch[k] = v.to(device)
                optimizer.zero_grad()
                
                # 1. Standard Prediction Error (L_d)
                pred_original = model(batch)
                loss_d = criterion(pred_original.squeeze(), batch['global_label'].squeeze())
                
                # 2. Physics-Informed Perturbation Loss (L_r)
                perturbed_batch = batch.copy()
                perturbed_batch['static_features'] = perturb_features(batch['static_features'])
                pred_perturbed = model(perturbed_batch)
                loss_r = criterion(pred_original.squeeze(), pred_perturbed.squeeze())
                
                # 3. Prior Knowledge Loss for Non-Lithium systems (L_noLi)
                loss_no_li = torch.tensor(0.0, device=device)
                if 3 in batch['atomic_numbers']:
                    no_li_batch = batch.copy()
                    # Synthetically substitute Li (3) with Na (11) to enforce zero-conductivity baseline
                    no_li_atomic_numbers = no_li_batch['atomic_numbers'].clone()
                    no_li_atomic_numbers[no_li_atomic_numbers == 3] = 11 
                    no_li_batch['atomic_numbers'] = no_li_atomic_numbers
                    
                    pred_no_li = model(no_li_batch)
                    loss_no_li = criterion(pred_no_li.squeeze(), torch.tensor(0.0, device=device))

                # 4. Aggregate Loss function (Equation 5 in manuscript)
                total_loss = loss_d + RULE_WEIGHT * loss_r + NO_LI_WEIGHT * loss_no_li
                
                if torch.isnan(total_loss): continue
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                
                train_ld_list.append(loss_d.item())
                train_lr_list.append(loss_r.item())
                train_lnl_list.append(loss_no_li.item())

            avg_train_ld = np.mean(train_ld_list) if train_ld_list else 0
            avg_train_lr = np.mean(train_lr_list) if train_lr_list else 0
            avg_train_lnl = np.mean(train_lnl_list) if train_lnl_list else 0
            
            # Validation Phase
            model.eval()
            val_loss_list = []
            with torch.no_grad():
                for batch in val_loader:
                    for k, v in batch.items():
                        if isinstance(v, torch.Tensor): batch[k] = v.to(device)
                    pred = model(batch)
                    loss = criterion(pred.squeeze(), batch['global_label'].squeeze())
                    if not torch.isnan(loss): 
                        val_loss_list.append(loss.item())
            
            avg_val_mae = np.mean(val_loss_list) if val_loss_list else 0
            print(f"--- Epoch {epoch+1:03d}/200 --- L_d: {avg_train_ld:.4f} | L_r: {avg_train_lr:.4f} | L_noLi: {avg_train_lnl:.4f} || Val MAE: {avg_val_mae:.4f}")
            
            scheduler.step(avg_val_mae)
            
            # Model Checkpointing
            if avg_val_mae < best_val_loss:
                best_val_loss = avg_val_mae
                patience_counter = 0
                torch.save(model.state_dict(), SAVED_MODEL_PATH)
                with open(SAVED_SCALER_PATH, 'wb') as f: pickle.dump(feature_scaler_instance, f)
                with open(SAVED_SPG_MAP_PATH, 'wb') as f: pickle.dump(SPACEGROUP_MAP, f)
                print(f"  *** New optimal Val MAE: {best_val_loss:.4f}. Model checkpoints saved. ***")
            else:
                patience_counter += 1
            
            if patience_counter >= PATIENCE_LIMIT:
                print(f"\n[INFO] Validation MAE has not improved for {PATIENCE_LIMIT} epochs. Early stopping triggered.")
                break

        print("\n======== Training Pipeline Completed ========")
        print(f"Best Validation MAE achieved: {best_val_loss:.4f}")
        
    except Exception as e:
        print(f"\n[FATAL ERROR] Pipeline terminated unexpectedly: {e}")
        traceback.print_exc()