# **Anonymous Code Repository for Peer Review**

This repository contains a demonstration package of the physics-informed deep learning platform reported in the manuscript. To preserve the intellectual property of ongoing large-scale database generation while satisfying the peer-review transparency requirements, this package isolates the core innovation of our work: **The Physics-Informed Neural Network (PINN) for Ionic Conductivity Prediction**.

This stripped-down version allows reviewers to locally verify the mathematical frameworks, physical constraints, and predictive capability without requiring access to external supercomputing (HPC/SLURM) clusters.

## **1\. Environment Requirements**

The scripts are written in Python and utilize standard machine learning and materials science libraries.

Recommended dependencies:

* Python \>= 3.8
* PyTorch \>= 1.10.0
* pymatgen \>= 2022.0.0  
* pandas, numpy, scikit-learn

## **2\. Directory Structure**

Ensure the provided package follows this structure before execution:

|-- train\_pinn.py \# The core training script with physics-informed loss functions

|-- predict\_pinn.py \# The batch prediction script

|-- train\_data/ \# Contains sample .poscar files and target.xlsx for training

|-- predict\_data/ \# Contains .poscar files for target prediction evaluation

|-- README.txt \# This file

## **3\. How to Run the Code**

### **Step 3.1: Train the Model**

Run the training script to initialize the Graph Neural Network (GNN) and apply physical constraints during training.

Command:

python train\_pinn.py

Outputs:

Upon successful execution or triggering early stopping, the script will generate three necessary checkpoint files in the root directory:

* pinn\_conductivity\_model.pth (The trained model weights)  
* feature\_scaler.pkl (StandardScaler for the 30 atomic features)  
* spacegroup\_map.pkl (Vocabulary mapping for crystallographic symmetry)

### **Step 3.2: Predict Ionic Conductivity**

Once the model is successfully trained, you can evaluate new inorganic crystals located in the predict\_data folder.

Command:

python predict\_pinn.py

Output:

The script will output the predicted room-temperature ionic conductivity (in log mS/cm) for each crystal structure in the terminal.

## **Note on Physics Constraints**

Reviewers can inspect the perturb\_features() function in train\_pinn.py to verify how the physical rules (Coulombic Interactions, Lattice Stability, Skeleton Rigidity, etc.) described in Equation 5 of the manuscript are mathematically enforced in the gradient descent loop.